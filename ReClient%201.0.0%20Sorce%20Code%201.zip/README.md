# ReClient 1.0.0

Client-side Fabric utility mod for Minecraft Java 1.21.1. Crosshair Indicator is not included. Cosmetics are not included.

## Current modules

- HUD: FPS, CPS, ping, coordinates, direction, clock, memory, keystrokes and armor
- Utility: zoom, toggle sprint, fullbright and mobile performance preset
- Visual/PvP options: Motion Blur (experimental), No Overlays and Crystal Optimizer (their actual in-game effects require verification on the target Minecraft setup)
- HUD editor, theme settings, performance presets and JSON configuration persistence

## Build

Requires Java 21 and network access for Gradle/Minecraft dependencies. From this directory run:

```sh
./gradlew clean build
```

The remapped mod JAR, if the build succeeds, is produced under `build/libs/`. This source archive has not been verified as a successful build.

## Credits

Credit: 4Repeat — https://youtube.com/@4repeat?si=XZeLrI6b6tMgAmAE
