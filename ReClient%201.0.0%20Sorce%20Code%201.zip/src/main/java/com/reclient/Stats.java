package com.reclient;

import java.util.ArrayDeque;
import java.util.Deque;

import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Per-frame statistics: FPS, frame delta and clicks per second. Updated once per rendered frame. */
public final class Stats {
	private static int frames;
	private static long lastFpsNs = System.nanoTime();
	private static long lastFrameNs = System.nanoTime();
	private static int fps;
	private static float dt = 0.016f;

	private static boolean leftDown, rightDown;
	private static final Deque<Long> LEFT = new ArrayDeque<>();
	private static final Deque<Long> RIGHT = new ArrayDeque<>();

	private Stats() {}

	public static void frame(Minecraft mc) {
		long now = System.nanoTime();
		dt = Math.min(0.1f, (now - lastFrameNs) / 1_000_000_000f);
		lastFrameNs = now;

		frames++;
		if (now - lastFpsNs >= 500_000_000L) {
			fps = (int) Math.round(frames * 1_000_000_000.0 / (now - lastFpsNs));
			frames = 0;
			lastFpsNs = now;
		}

		long handle = mc.getWindow().getWindow();
		boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
		long ms = System.currentTimeMillis();
		if (mc.screen == null) {
			if (l && !leftDown) LEFT.addLast(ms);
			if (r && !rightDown) RIGHT.addLast(ms);
		}
		leftDown = l && mc.screen == null;
		rightDown = r && mc.screen == null;
		prune(LEFT, ms);
		prune(RIGHT, ms);
	}

	private static void prune(Deque<Long> q, long now) {
		while (!q.isEmpty() && now - q.peekFirst() > 1000L) q.pollFirst();
	}

	public static int fps() { return fps; }
	public static float dt() { return dt; }
	public static int cpsLeft() { return LEFT.size(); }
	public static int cpsRight() { return RIGHT.size(); }
	public static boolean leftDown() { return leftDown; }
	public static boolean rightDown() { return rightDown; }
}
