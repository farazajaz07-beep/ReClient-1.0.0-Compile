package com.reclient.module;

import java.util.ArrayList;
import java.util.List;

import com.reclient.Theme;
import com.reclient.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class ArmorModule extends HudModule {
	private final BoolSetting held = bool("Held Item", true);

	public ArmorModule(int x, int y) {
		super("Armor Status", "Armor and held item with durability.", x, y);
	}

	private List<ItemStack> stacks(Minecraft mc) {
		List<ItemStack> list = new ArrayList<>();
		Player p = mc.player;
		if (p == null) return list;
		for (EquipmentSlot slot : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
			ItemStack s = p.getItemBySlot(slot);
			if (!s.isEmpty()) list.add(s);
		}
		if (held.value && !p.getMainHandItem().isEmpty()) list.add(p.getMainHandItem());
		return list;
	}

	private static String info(ItemStack s) {
		if (s.isDamageableItem()) return Integer.toString(s.getMaxDamage() - s.getDamageValue());
		return s.getCount() > 1 ? "x" + s.getCount() : "";
	}

	@Override
	protected int contentWidth(Minecraft mc, Font font) {
		List<ItemStack> list = stacks(mc);
		if (list.isEmpty()) return editing ? font.width("Armor") : 0;
		int max = 0;
		for (ItemStack s : list) max = Math.max(max, font.width(info(s)));
		return 20 + Math.max(max, 12);
	}

	@Override
	protected int contentHeight(Minecraft mc, Font font) {
		int n = stacks(mc).size();
		if (n == 0) return editing ? 8 : 0;
		return n * 18 - 2;
	}

	@Override
	protected void drawContent(GuiGraphics g, Minecraft mc, Font font, int w, int h) {
		List<ItemStack> list = stacks(mc);
		if (list.isEmpty()) {
			g.drawString(font, "Armor", 0, 0, 0xFF868C9C, false);
			return;
		}
		int y = 0;
		for (ItemStack s : list) {
			g.renderItem(s, 0, y);
			g.renderItemDecorations(font, s, 0, y);
			if (s.isDamageableItem()) {
				float frac = 1f - (float) s.getDamageValue() / s.getMaxDamage();
				int color = 0xFF000000 | Theme.hsv(frac / 3f, 0.8f, 1f);
				g.drawString(font, info(s), 20, y + 4, color, Theme.textShadow);
			} else {
				g.drawString(font, info(s), 20, y + 4, 0xFFFFFFFF, Theme.textShadow);
			}
			y += 18;
		}
	}
}
