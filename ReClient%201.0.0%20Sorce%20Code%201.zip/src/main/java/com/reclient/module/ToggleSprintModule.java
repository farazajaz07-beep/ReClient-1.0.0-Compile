package com.reclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public class ToggleSprintModule extends Module {
	public ToggleSprintModule() {
		super("Toggle Sprint", "Sprint automatically while moving forward.", Category.UTILITY);
	}

	@Override
	public void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null || mc.screen != null) return;
		boolean canSprint = p.getFoodData().getFoodLevel() > 6 || p.getAbilities().mayfly;
		if (mc.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.isUsingItem() && !p.horizontalCollision && canSprint) {
			p.setSprinting(true);
		}
	}
}
