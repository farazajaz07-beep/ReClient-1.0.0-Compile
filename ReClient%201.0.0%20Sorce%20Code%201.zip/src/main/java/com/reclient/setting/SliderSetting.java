package com.reclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class SliderSetting extends Setting {
	public double value;
	public final double min, max, step;

	public SliderSetting(String name, double value, double min, double max, double step) {
		super(name);
		this.value = value;
		this.min = min;
		this.max = max;
		this.step = step;
	}

	public int asInt() {
		return (int) Math.round(value);
	}

	public double fraction() {
		return (value - min) / (max - min);
	}

	public void setFraction(double f) {
		f = Math.max(0, Math.min(1, f));
		double v = min + f * (max - min);
		v = Math.round(v / step) * step;
		value = Math.max(min, Math.min(max, v));
	}

	public String display() {
		if (step >= 1) return Integer.toString((int) Math.round(value));
		return String.format("%.2f", value);
	}

	@Override
	public JsonElement save() {
		return new JsonPrimitive(value);
	}

	@Override
	public void load(JsonElement element) {
		if (element != null && element.isJsonPrimitive()) {
			value = Math.max(min, Math.min(max, element.getAsDouble()));
		}
	}
}
